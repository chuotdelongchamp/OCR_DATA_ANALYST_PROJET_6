
#On importe les librairies utiles
library (plyr)
library(dplyr)
library(factoextra)
library(repr)
library(tibble)
library(corrplot)
library(lattice)
library(caret)
library(e1071)

df_billets <- read.csv("/Users/utilisateur/Google Drive/OC Data Analyst HUOT DE LONGCHAMP Charles/PROJET 6/billets.csv")


head(df_billets,3)

summary(df_billets)

df_na <- df_billets[rowSums(is.na(df_billets)) > 0,] #Afficher tous les NA dans toutes les variables
df_na

df_real <- filter(df_billets, is_genuine == "True")
df_fake <- filter(df_billets, is_genuine == "False")

options(repr.plot.width=5, repr.plot.height=5)#taille du graph

x1 <- df_real$length
x2 <- df_fake$length

## Histogrammes non-imprimés :
bp1 <- hist(x1, plot=FALSE)
bp2 <- hist(x2, plot=FALSE)

## Calcul de minima/maxima :
hlims <- range(c(bp1$breaks, bp2$breaks))
vlims <- range(c(bp1$counts, bp2$counts))

## Couleurs de remplissage, dont une avec ajout de transparence :
histcol <- sapply(apply(rbind(col2rgb(c("green", "red"))/255,
                              alpha = c(1, 0.5)), # Première couleur opaque, 50% de transparence pour la seconde.
                        2, as.list),
                  do.call, what = rgb)

## Création du graphique :
hist(x1, border="black", xlim=hlims, ylim=vlims, xlab="mesures en mm", ylab="fréquence",        
     col=histcol[1], main="différences longueurs vrais/faux")

hist(x2, border="black", add=TRUE,
     breaks=seq(from=min(hlims), to=max(hlims), by=diff(bp1$breaks[1:2])), # ...largeur de classes égale à celle
                                                                           # du précédent graphique
     col=histcol[2])      # Couleur transparente (en sur-impression).

legend(171, 30, legend=c("vrai billet", "faux billet"),
       col=c(histcol[1], histcol[2]), lty=1:1,lwd=6:6, cex=1,box.lty=0,y.intersp=2)

dev.copy(png,'hist_diff_longueurs.png')
dev.off()

x1 <- df_real$height_left
x2 <- df_fake$height_left

## Histogrammes non-imprimés :
bp1 <- hist(x1, plot=FALSE)
bp2 <- hist(x2, plot=FALSE)

## Calcul de minima/maxima :
hlims <- range(c(bp1$breaks, bp2$breaks))
vlims <- range(c(bp1$counts, bp2$counts))

## Couleurs de remplissage, dont une avec ajout de transparence :
histcol <- sapply(apply(rbind(col2rgb(c("green", "red"))/255,
                              alpha = c(1, 0.5)), # Première couleur opaque, 50% de transparence pour la seconde.
                        2, as.list),
                  do.call, what = rgb)

## Création du graphique :
hist(x1, border="black", xlim=hlims, ylim=vlims, xlab="mesures en mm", ylab="fréquence",           
     col=histcol[1], main="différences hauteurs gauches vrais/faux")

hist(x2, border="black", add=TRUE,
     breaks=seq(from=min(hlims), to=max(hlims), by=diff(bp1$breaks[1:2])), # ...largeur de classes égale à celle
                                                                           # du précédent graphique
     col=histcol[2])      # Couleur transparente (en sur-impression).

legend(104.43, 25, legend=c("vrai billet", "faux billet"),
       col=c(histcol[1], histcol[2]), lty=1:1,lwd=6:6, cex=1,box.lty=0,y.intersp=2)

dev.copy(png,'hist_diff_hauteurs_gauches.png')
dev.off()

x1 <- df_real$height_right
x2 <- df_fake$height_right

## Histogrammes non-imprimés :
bp1 <- hist(x1, plot=FALSE)
bp2 <- hist(x2, plot=FALSE)

## Calcul de minima/maxima :
hlims <- range(c(bp1$breaks, bp2$breaks))
vlims <- range(c(bp1$counts, bp2$counts))

## Couleurs de remplissage, dont une avec ajout de transparence :
histcol <- sapply(apply(rbind(col2rgb(c("green", "red"))/255,
                              alpha = c(1, 0.5)), # Première couleur opaque, 50% de transparence pour la seconde.
                        2, as.list),
                  do.call, what = rgb)

## Création du graphique :
hist(x1, border="black", xlim=hlims, ylim=vlims, xlab="mesures en mm", ylab="fréquence",           
     col=histcol[1], main="différences hauteurs droites vrais/faux")

hist(x2, border="black", add=TRUE,
     breaks=seq(from=min(hlims), to=max(hlims), by=diff(bp1$breaks[1:2])), # ...largeur de classes égale à celle
                                                                           # du précédent graphique
     col=histcol[2])      # Couleur transparente (en sur-impression).

legend(104, 30, legend=c("vrai billet", "faux billet"),
       col=c(histcol[1], histcol[2]), lty=1:1,lwd=6:6, cex=1,box.lty=0,y.intersp=2)

dev.copy(png,'hist_diff_hauteurs_droites.png')
dev.off()

x1 <- df_real$margin_low
x2 <- df_fake$margin_low

## Histogrammes non-imprimés :
bp1 <- hist(x1, plot=FALSE)
bp2 <- hist(x2, plot=FALSE)

## Calcul de minima/maxima :
hlims <- range(c(bp1$breaks, bp2$breaks))
vlims <- range(c(bp1$counts, bp2$counts))

## Couleurs de remplissage, dont une avec ajout de transparence :
histcol <- sapply(apply(rbind(col2rgb(c("green", "red"))/255,
                              alpha = c(1, 0.5)), # Première couleur opaque, 50% de transparence pour la seconde.
                        2, as.list),
                  do.call, what = rgb)

## Création du graphique :
hist(x1, border="black", xlim=hlims, ylim=vlims, xlab="mesures en mm", ylab="fréquence",           
     col=histcol[1], main="différences marges basses vrais/faux")

hist(x2, border="black", add=TRUE,
     breaks=seq(from=min(hlims), to=max(hlims), by=diff(bp1$breaks[1:2])), # ...largeur de classes égale à celle
                                                                           # du précédent graphique
     col=histcol[2])      # Couleur transparente (en sur-impression).

legend(5, 20, legend=c("vrai billet", "faux billet"),
       col=c(histcol[1], histcol[2]), lty=1:1,lwd=6:6, cex=1,box.lty=0,y.intersp=2)

dev.copy(png,'hist_diff_marges_basses.png')
dev.off()

x1 <- df_real$margin_up
x2 <- df_fake$margin_up

## Histogrammes non-imprimés :
bp1 <- hist(x1, plot=FALSE)
bp2 <- hist(x2, plot=FALSE)

## Calcul de minima/maxima :
hlims <- range(c(bp1$breaks/2, bp2$breaks))
vlims <- range(c(bp1$counts, bp2$counts))

## Couleurs de remplissage, dont une avec ajout de transparence :
histcol <- sapply(apply(rbind(col2rgb(c("green", "red"))/255,
                              alpha = c(1, 0.5)), # Première couleur opaque, 50% de transparence pour la seconde.
                        2, as.list),
                  do.call, what = rgb)

## Création du graphique :
hist(x1, border="black", xlim=hlims, ylim=vlims, xlab="mesures en mm", ylab="fréquence",           
     col=histcol[1], main="différences marges hautes vrais/faux")

hist(x2, border="black", add=TRUE,
     breaks=seq(from=min(hlims), to=max(hlims), by=diff(bp1$breaks[1:2])), # ...largeur de classes /2 pour arriver
                                                                             # au même écart de 0.1
     col=histcol[2])      # Couleur transparente (en sur-impression).

legend(1, 30, legend=c("vrai billet", "faux billet"),
       col=c(histcol[1], histcol[2]), lty=1:1,lwd=6:6, cex=1,box.lty=0,y.intersp=2)

dev.copy(png,'hist_diff_marges_hautes.png')
dev.off()

x1 <- df_real$diagonal
x2 <- df_fake$diagonal

## Histogrammes non-imprimés :
bp1 <- hist(x1, plot=FALSE)
bp2 <- hist(x2, plot=FALSE)

## Calcul de minima/maxima :
hlims <- range(c(bp1$breaks, bp2$breaks))
vlims <- range(c(bp1$counts, bp2$counts))

## Couleurs de remplissage, dont une avec ajout de transparence :
histcol <- sapply(apply(rbind(col2rgb(c("green", "red"))/255,
                              alpha = c(1, 0.5)), # Première couleur opaque, 50% de transparence pour la seconde.
                        2, as.list),
                  do.call, what = rgb)

## Création du graphique :
hist(x1, border="black", xlim=hlims, ylim=vlims, xlab="mesures en mm", ylab="fréquence",           
     col=histcol[1], main="différences diagonales vrais/faux")

hist(x2, border="black", add=TRUE,
     breaks=seq(from=min(hlims), to=max(hlims), by=diff(bp1$breaks[1:2])), # ...largeur de classes égale à celle
                                                                           # du précédent graphique
     col=histcol[2])      # Couleur transparente (en sur-impression).

legend(110, 25, legend=c("vrai billet", "faux billet"),
       col=c(histcol[1], histcol[2]), lty=1:1,lwd=6:6, cex=1,box.lty=0,y.intersp=2)

dev.copy(png,'hist_diff_diagonales.png')
dev.off()

res.pca <- prcomp(df_billets[2:7], center = TRUE, scale = TRUE) #option centrer et reduire en TRUE
var <- get_pca_var(res.pca)

# analyse de la qualité de représentation des axes
options(repr.plot.width=4, repr.plot.height=4)#taille du graph

fviz_eig(res.pca, addlabels = TRUE, ylim = c(0, 60), main="Qualité de représentation des axes") 


dev.copy(png,'eboulis des valeurs propres.png')
dev.off()

#Heatmap de la qualité des représentations
options(repr.plot.width=4, repr.plot.height=4)#taille du graph

corrplot(var$contrib, is.corr=FALSE,mar=c(0,0,2,0), title="Heatmap des contributions") #Heatmap des contributions

dev.copy(png,'heatmap des contributions.png')
dev.off()

#Cercle des corrélations
fviz_pca_var(res.pca,axes = c(1,2), col.var="contrib",
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE, title ="cercle des corrélations") # Eviter d'avoir du chevauchement sur le texte

dev.copy(png,'cercle des corrélations.png')
dev.off()

options(repr.plot.width=6, repr.plot.height=4)#taille du graph

fviz_pca_ind(res.pca, axes = c(1,2), label="none", habillage=df_billets$is_genuine,
             addEllipses=TRUE, ellipse.level=0.95, title="repésentation des billets axes 1 et 2")

dev.copy(png,'représentation des billets axe 1_2.png')
dev.off()

fviz_pca_ind(res.pca, axes = c(1,3), label="none", habillage=df_billets$is_genuine,
             addEllipses=TRUE, ellipse.level=0.95, title="repésentation des billets axes 1 et 3")

dev.copy(png,'représentation des billets axe 1_3.png')
dev.off()

fviz_pca_ind(res.pca, axes = c(2,3), label="none", habillage=df_billets$is_genuine,
             addEllipses=TRUE, ellipse.level=0.95, title="repésentation des billets axes 2 et 3")

dev.copy(png,'représentation des billets axe 2_3.png')
dev.off()

#connaitre le nombre de cluster optimal
fviz_nbclust(df_billets[2:7], kmeans, method = "silhouette", print.summary = TRUE)#Méthode de la silhouette

dev.copy(png,'nombre optimal de clusters Kmeans.png')
dev.off()

# clustering en 2 cluster Kmeans
res <- hkmeans(df_billets[2:7], k = 2)
# J'ajoute la variable cluster à mon DataFrame
df_billets[,"cluster"] <- res$cluster

fviz_pca_ind(res.pca, label="none", habillage=res$cluster,
             addEllipses=TRUE, ellipse.level=0.95, title="repésentation des billets selon clusters Kmeans")

dev.copy(png,'représentation des billets selon clusters Kmeans.png')
dev.off()

#Je cherche les outliers

df_faux_negatif <- filter(df_billets, is_genuine == "True" & cluster == 2)
df_faux_positif <- filter(df_billets, is_genuine == "False" & cluster == 1)

df_faux_negatif
df_faux_positif

# clustering en 2 cluster CAH
res <- hcut(df_billets[2:7], k = 2, stand = TRUE)

# J'ajoute la variable cluster à mon DataFrame
df_billets[,"cluster"] <- res$cluster

fviz_pca_ind(res.pca, label="none", habillage=res$cluster,
             addEllipses=TRUE, ellipse.level=0.95, title="repésentation des billets selon clusters CAH")

dev.copy(png,'représentation des billets selon clusters CAH.png')
dev.off()

#Je cherche les outliers

df_faux_negatif <- filter(df_billets, is_genuine == "True" & cluster == 1)
df_faux_positif <- filter(df_billets, is_genuine == "False" & cluster == 2)

df_faux_negatif
df_faux_positif

# On ensemence pour la répétabilité
set.seed(5678)

# On utilise la fonction createDataPartition pour créer 1 jeu d'entrainement et un jeu de test (70 - 30 %) avec les mêmes proportion de True et de False que le jeu complet
trainIndex <- createDataPartition(df_billets$is_genuine, p = .7, list = FALSE, times = 1)

# On créé nos 2 jeux
billetsTrain <- df_billets[ trainIndex,]
billetsTest <- df_billets[-trainIndex,]

regression = glm(formula= is_genuine ~ .,data=billetsTrain[1:7] ,family=binomial(logit))
regr = step(regression)

# Création du modèle le plus optimal :
model <- glm(formula= is_genuine ~ margin_low + margin_up + diagonal, data=billetsTrain, family=binomial(logit))

# On effectue un prédiction sur notre jeu de test
predict <- as.vector(predict(model, newdata=billetsTest, type="response"))

# On regarde les probabilités de chaque classe de billets
p_class <- ifelse(predict > .5, "True", "False")

# On affiche la matrice de confusion (version caret)
confusionMatrix(p_class, billetsTest[["is_genuine"]])

#mettre l'adresse du fichier test
df_test <- read.csv("/Users/utilisateur/Google Drive/OC Data Analyst HUOT DE LONGCHAMP Charles/PROJET 6/exemple.csv")

rownames(df_test) <- df_test$id # crée l'index à partir de l'id

df_resultats <- data.frame(predict(model, df_test, type="response")) #création du df en lancant predict()

#création de la colonne d'interprétation
df_resultats$interpretation <- ifelse(df_resultats$predict.model..df_test..type....response..>=0.5, "vrai billet", "faux billet")


df_resultats
